These files are part of the ZX Spectrum Next project and can be downloaded 
from the repository as "tbblue.zip":

https://gitlab.com/SpectrumNext/ZX_Spectrum_Next_FPGA/-/tree/master/cores/zxnext/src/rom?ref_type=heads

# ZX SPECTRUM NEXT BOOT CODE

Binaries named "boot-nnnnn.bin" and "boot-nnnnn-ab.bin" contain the 8K of
Z80 code executed on power up by the regular ZX Next core and the AB core
respectively.  The "nnnnn" in the names correspond to the core version where
the boot code initially appeared.

An exception to this naming concerns these two files:

boot-30204rc.bin
boot-30204rc-ab.bin

This was boot code used in core version 3.02.04 at intermediate stages of
development and are deprecated.  The files are retained for use by existing
emulators.  The final boot code incorporated into core version 3.02.04
follows the naming convention.

# LICENSING

Most code is written by members of the ZX Spectrum Next team.

A limited FAT implementation is contained with origins from the Minimig project
(c) Dennis van Weeren, Jakub Bednarski and AMR.  Adaptations were made by
members of the ZX Spectrum Next team.

All code above is covered under the GPL3 license.

In versions prior to 30204, the ZX Spectrum Sinclar ROM font is included in
binary form.  SpecNext only has a license to use Sinclair ROMs in its own
projects that does not extend to other usage.  Instead, the ROM font can be used
under permission given to emulator authors by Cliff Lawson of Amstrad in 1999.
This permission allows non-commercial desktop emulators to use the Sinclair ROMs.

Starting in version 30204, the boot code replaces the Spectrum ROM font with a
"sinclair.fzx" font that is freeware, meaning free for use but copyrighted.  The
font's copyright belongs to Proxima Software:

https://spectrumcomputing.co.uk/entry/23578/ZX-Spectrum/Klub_u%C5%BEivatel%C5%AF_Desktopu_1 

Conversion to fzx format was carried out by Einar Saukas:

https://spectrumcomputing.co.uk/entry/0028183

The fzx format itself was created by Andrew Owen.  Information available here:

https://github.com/z88dk/z88dk/tree/master/libsrc/font/fzx

FZX code was written by a member of the ZX Spectrum Next team and is also available
through z88dk.

# LICENSING SUMMARY

License applied to boot code versions 30204 and later is GPL3.  The GPL3 license is
included in this zip file.

License applied to versions earlier than 30204 is the narrowest applicable license
provided by Cliff Lawson of Amstrad owing to the presence of the original Spectrum
ROM font.  This license permits use of the boot code in non-commercial desktop
emulators only.
